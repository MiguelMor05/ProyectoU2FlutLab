package com.mycompany.proyectou2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
