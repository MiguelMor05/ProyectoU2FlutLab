// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/pages/info/info_widget.dart' show InfoWidget;
export '/pages/productos/productos_widget.dart' show ProductosWidget;
export '/pages/pago/pago_widget.dart' show PagoWidget;
export '/pages/usuario/usuario_widget.dart' show UsuarioWidget;
export '/pages/registros/registros_widget.dart' show RegistrosWidget;
export '/pages/empleado/empleado_widget.dart' show EmpleadoWidget;
export '/pages/producto/producto_widget.dart' show ProductoWidget;
export '/pages/venta/venta_widget.dart' show VentaWidget;
